
const BASE_URL = 'http://WSTEMFB32-17:8084/APIGateway1/Gateway';

//GET USERS

$(document).ready(function () {
    var password = $("#adminPassword").val();
    $.ajax({
        url: BASE_URL,
        type: 'GET',
        dataType: 'text',
       // data: `action=adminLogin&adminPassword=${password}`,
        data: `action=adminLogin&adminPassword=123`,
        success: function (data) {
            console.log("get");
            console.log(data)
            $("#listUsers").html(data);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR)
            console.log(textStatus, errorThrown);
        }
    });
});

//ADD AN USER
$(document).ready(function () {
    $("#addUser").on("click", function () {
        $("#delUserInputs").hide()
        $("#modUserInputs").hide()
        $("#addUserInputs").show()
    });

    $("#addUserConfirm").click((e) => {
        var username = $("#addusername").val();
        var password = $("#addpassword").val();
        console.log(username);
        $.ajax({
            type: "POST",
            dataType: "json",
            url: BASE_URL,
            data: {action: "addUser", username: username, password: password},
            success: function (data) {
                alert("User added");
                refreshUserlist();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(jqXHR);
                console.log(textStatus, errorThrown);
            }
        });
    })
});

//MODIFY USER
$(document).ready(function () {
    $("#modifyUser").on("click", function () {
        $("#delUserInputs").hide()
        $("#addUserInputs").hide()
        $("#modUserInputs").show()
    });

    $("#modUserConfirm").click((e) => {
        var username = $("#modusername").val();
        var password = $("#modpassword").val();
        var userId = $("#users option:selected").val();
        $.ajax({
            type: "POST",
            url: BASE_URL,
            data: {action: "modUser", username: username, password: password, userId: userId},
            success: function (data) {
                alert("User modified")
                $("#modUserInputs").hide();
                refreshUserlist();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(jqXHR);
                console.log(textStatus, errorThrown);
            }
        });

    })
});
//DELETE USER
$(document).ready(function () {
    $("#deleteUser").on("click", function () {
        $("#modUserInputs").hide()
        $("#addUserInputs").hide() 
        $("#delUserInputs").show()
    });

    $("#delUserConfirm").click((e) => {
        var userId = $("#users option:selected").val();
        $.ajax({
            type: "POST",
            url: BASE_URL,
            dataType: 'text',
            data: {action: "delUser", userId: userId},
            success: function (data) {
                alert("User deleted")
                refreshUserlist();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(jqXHR);
                console.log(textStatus, errorThrown);
            }
        });
        
    })
});

function refreshUserlist(){
    $.ajax({
        type: "GET",
        url: BASE_URL,
        dataType: 'text',
        data: {action: "users"},
        success: function (data) {
            $("#listUsers").html(data);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
            console.log(textStatus, errorThrown);
        }
    });
}