$(document).ready(function () {
    $("#loginForm").on("submit", (e => {
        e.preventDefault();
        var password = $('input[name="adminPassword"]').val();

        $.ajax({
            type: "GET",
            dataType: "json",
            url: "http://localhost:8085/APIGateway1/Gateway",
            data: "action=adminLogin&adminPassword=" + password,
            success: (data) => {
                window.location.href = "adminView.html"
            },
            error: (err) => {
                console.log(err)
            },
        });
    }))

    
});